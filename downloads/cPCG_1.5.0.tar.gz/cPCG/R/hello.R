
## a placeholder
hello <- function(txt = "world") {
    cat("Hello, ", txt, "\n")
}
